#!/bin/bash

. ./cmd.sh


# ...

local/nnet2/run_5c.sh

